#Author: Opeyemi Adesina
#Institution: University of the Fraser Valley
#Academic Session: Fall, 2020

#-------------------------------------------# Problem Analysis #-------------------------------------------#



#-------------------------------------------# End of Problem Analysis #-------------------------------------------#    

from math import sqrt #imports only the square root operation from the math module

#receiving number of employees as an input from the user 
numberOfEmployees = int(input("Enter the number of employees: "))

#operation builds gross income list from user input
def buildGrossIncomeList( numberOfEmployees ) : #Step 1

    #creating and initializing income list as empty
    grossIncomeList = []
    i = 0
    
    print("\n\n------------------------- Enter Employees' Salaries (i.e., Gross Incomes) Below -------------------------")
    while ( i < numberOfEmployees ) :
        grossIncome = input("Enter an employee's gross income: ")
        
        #checking if the value entered is an empty string or not
        if ( grossIncome.strip() == "" ) :
            print("Gross income can't be an empty string...")
            grossIncome = input("Re-enter the employee's gross income: ")
        
        #type conversioning from string to floating point number - monies should be in float
        grossIncome = float( grossIncome )
        if ( grossIncome < 0.0 ) :
            print("Gross income can't be negative...")
            grossIncome = float( input("Re-enter non-negative value for the employee's gross income: ") )
        
        grossIncomeList.append( grossIncome )    
        i += 1
    return grossIncomeList

#operation computes provincial taxes for the input gross income...
def computeProvTaxes( grossIncome ) : #Step 2.1.1

    ##-----------------------------------------##
    ## Insert your code here!!!
    ##-----------------------------------------##
    
    return 0.0
    

#operation computes federal taxes for the input gross income 
def computeFedTaxes( grossIncome ) : #Step 2.1.2

    ##-----------------------------------------##
    ## Insert your code here!!!
    ##-----------------------------------------##
    
    return 0.0
    
    
### Beginning of Step 3 - Computing employee's CPP
def computeCPP( grossIncome ) :
  
  ##-----------------------------------------##
  ## Insert your code here!!!
  ##-----------------------------------------##
  
  return 0.0

### Beginning of Step 4 - Computing employee's EI
def computeEI( grossIncome ) :
  
  ##-----------------------------------------##
  ## Insert your code here!!!
  ##-----------------------------------------##
  
  return 0.0
  
def computeHealthPremium( grossIncome ) :

    ##-----------------------------------------##
    ## Insert your code here!!!
    ##-----------------------------------------##
    
    return 0.0

#Function computes net incomes by invoking 
def computeNetIncomes( grossIncomeList ) : #Step 2
    
  netIncomeList = [] #creating and initializing the net income list
    
  ##-----------------------------------------##
  ## Insert your code here!!!
  ##-----------------------------------------##
    
  return netIncomeList
  
#Function computes net incomes by invoking 
def computeDeductions( grossIncomeList ) : #Step 2
    
  totalDeductionsList = [] #creating and initializing the net income list
  
  ##-----------------------------------------##
  ## Insert your code here!!!
  ##-----------------------------------------##
    
  return totalDeductionsList

#function computes mean or average of a set of numbers
def mean( inputList ) : #Step 3
    
    ##-----------------------------------------##
    ## Insert your code here!!!
    ##-----------------------------------------##
    
    return 0.0
    
def standardDeviation( inputList ) : #Step 4
    
    ##-----------------------------------------##
    ## Insert your code here!!!
    ##-----------------------------------------##

    return 0.0
    
    
def normalize( inputList ) :

    ##-----------------------------------------##
    ## Insert your code here!!!
    ##-----------------------------------------##
    
    return inputList
            